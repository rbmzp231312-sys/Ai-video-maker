package com.aivideomaker.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private var selectedImage: Uri? = null
    private lateinit var status: TextView
    private lateinit var prompt: EditText
    private lateinit var imageLabel: TextView
    private val purple = Color.rgb(124, 77, 255)
    private val bg = Color.rgb(16, 16, 32)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(text("✨ AI VIDEO MAKER", 25, Color.WHITE, true))
        content.addView(text("अपना वीडियो बनाओ — टेक्स्ट या फोटो से", 14, 0xFFBDB8D8.toInt(), false).apply {
            setPadding(0, 8, 0, 22)
        })

        content.addView(section("1. वीडियो का आइडिया लिखो"))
        prompt = EditText(this).apply {
            hint = "उदाहरण: बारिश में दौड़ती स्पोर्ट्स कार, सिनेमैटिक कैमरा..."
            setHintTextColor(0xFF9A96AE.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            minLines = 4
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF29263D.toInt())
        }
        content.addView(prompt, params( -1, -2, 0, 10))

        content.addView(section("2. फोटो जोड़ो (वैकल्पिक)"))
        val pick = button("📷  फोन से फोटो चुनें")
        content.addView(pick, params(-1, 52, 0, 6))
        imageLabel = text("अभी कोई फोटो नहीं चुनी गई", 13, 0xFFBDB8D8.toInt(), false)
        content.addView(imageLabel)

        pick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            startActivityForResult(intent, 41)
        }

        content.addView(section("3. वीडियो सेटिंग"))
        content.addView(text("क्वालिटी", 14, Color.WHITE, true))
        val quality = Spinner(this)
        quality.adapter = adapter(listOf("4K Ultra HD (यदि AI सर्विस सपोर्ट करे)", "1080p Full HD", "720p HD"))
        content.addView(quality, params(-1, 52, 0, 8))

        content.addView(text("अवधि", 14, Color.WHITE, true).apply { setPadding(0, 10, 0, 0) })
        val duration = Spinner(this)
        duration.adapter = adapter(listOf("60 सेकंड", "90 सेकंड", "120 सेकंड"))
        content.addView(duration, params(-1, 52, 0, 8))

        content.addView(text("बनाने का तरीका", 14, Color.WHITE, true).apply { setPadding(0, 10, 0, 0) })
        val mode = Spinner(this)
        mode.adapter = adapter(listOf("टेक्स्ट + फोटो (Both)", "सिर्फ टेक्स्ट", "सिर्फ फोटो"))
        content.addView(mode, params(-1, 52, 0, 8))

        val generate = button("🚀  AI वीडियो बनाएं")
        content.addView(generate, params(-1, 56, 0, 18))
        status = text("तैयार! अपना आइडिया लिखें और सेटिंग चुनें।", 13, 0xFFBDB8D8.toInt(), false)
        content.addView(status)

        generate.setOnClickListener {
            val idea = prompt.text.toString().trim()
            if (idea.isEmpty() && selectedImage == null) {
                status.text = "पहले वीडियो का आइडिया लिखें या फोटो चुनें।"
            } else {
                status.text = "आपकी सेटिंग सेव हो गई हैं। असली AI रेंडरिंग के लिए AI वीडियो API/सर्वर जोड़ना बाकी है। इस डेमो में वीडियो जनरेट नहीं होगा।"
            }
        }
        setContentView(root)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun section(value: String) = text(value, 17, Color.WHITE, true).apply {
        setPadding(0, 18, 0, 10)
    }

    private fun button(value: String) = Button(this).apply {
        text = value
        textSize = 15f
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
    }

    private fun params(w: Int, h: Int, top: Int, bottom: Int) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(0, top, 0, bottom) }

    private fun adapter(items: List<String>) = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items).also {
        it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 41 && resultCode == RESULT_OK) {
            selectedImage = data?.data
            imageLabel.text = if (selectedImage != null) "फोटो चुनी गई ✓" else "अभी कोई फोटो नहीं चुनी गई"
        }
    }
}
